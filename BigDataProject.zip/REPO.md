
# Link to Dataset
[IOT-dataset](https://huggingface.co/datasets/Nora9029/NF-ToN-IoT-v2/tree/main)


# Link to repository
[Repository GitHub](https://github.com/PtrTella/BigDataProject)